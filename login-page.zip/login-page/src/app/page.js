"use client"; // Important for client-side interactivity
import { useState } from "react";
import UserCard from "../components/UserCard";

export default function Page() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [submittedUser, setSubmittedUser] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmittedUser({ name: form.name, email: form.email });
    setForm({ name: "", email: "", password: "" });
  };

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-start pt-16">
      {/* Sign-Up Form */}
      <form
        onSubmit={handleSubmit}
        className="bg-white p-8 rounded shadow-md w-full max-w-md"
      >
        <h2 className="text-2xl font-bold text-center mb-6 text-blue-600">
          Sign Up
        </h2>
        <input
          type="text"
          name="name"
          placeholder="Full Name"
          value={form.name}
          onChange={handleChange}
          className="border p-2 rounded w-full mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400"
          required
        />
        <input
          type="email"
          name="email"
          placeholder="Email Address"
          value={form.email}
          onChange={handleChange}
          className="border p-2 rounded w-full mb-4 focus:outline-none focus:ring-2 focus:ring-blue-400"
          required
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
          className="border p-2 rounded w-full mb-6 focus:outline-none focus:ring-2 focus:ring-blue-400"
          required
        />
        <button
          type="submit"
          className="bg-blue-600 text-white p-2 rounded w-full hover:bg-blue-700 transition"
        >
          Sign Up
        </button>
      </form>

      {/* UserCard Preview */}
      {submittedUser && (
        <div className="mt-8">
          <h3 className="text-xl font-semibold mb-4 text-center">
            Submitted User
          </h3>
          <UserCard name={submittedUser.name} email={submittedUser.email} />
        </div>
      )}
    </div>
  );
}
