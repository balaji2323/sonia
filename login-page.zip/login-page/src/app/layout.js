"use client";

import Navbar from "../components/Navbar";
import "./globals.css"; // ✅ fixed path

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main className="p-4">{children}</main>
      </body>
    </html>
  );
}
