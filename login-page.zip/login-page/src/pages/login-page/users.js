import UserCard from "../../components/UserCard";

export default function Users() {
  return (
    <div className="min-h-screen bg-blue-50 flex flex-wrap justify-center items-start gap-6 p-8">
      <UserCard name="Balaji" email="balaji@example.com" />
      <UserCard name="Sravya" email="sravya@example.com" />
      <UserCard name="John Doe" email="john@example.com" />
    </div>
  );
}
