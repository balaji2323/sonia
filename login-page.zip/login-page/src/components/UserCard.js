"use client";

export default function UserCard({ name, email }) {
  return (
    <div className="bg-white shadow-lg p-4 rounded-lg w-80">
      <h3 className="text-xl font-bold text-blue-600">{name}</h3>
      <p className="text-gray-700">{email}</p>
    </div>
  );
}
