/** @type {import('next').NextConfig} */
const nextConfig = {
  // You can keep other valid options here
}

module.exports = nextConfig
