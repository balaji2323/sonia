# Next.js Landing Page

This is a responsive landing page built with **Next.js, Tailwind CSS, and Framer Motion**.

## How to Run

1. Open terminal in your project folder
2. Run this command to install dependencies:
   ```bash
   npm install
   ```
3. Start the project with:
   ```bash
   npm run dev
   ```
4. Open your browser and go to:
   👉 http://localhost:3000

## Tools Used

- Next.js
- Tailwind CSS
- Framer Motion
